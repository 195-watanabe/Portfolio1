"use strict";

// スクロールで１ページ変わる
$.scrollify({
	section : ".box",
	scrollbars:"false",
	interstitialSection : "#header",
	easing: "swing",
	scrollSpeed: 300,
});

